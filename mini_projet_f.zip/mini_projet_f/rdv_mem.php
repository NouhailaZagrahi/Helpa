
<?php 
session_start();

// function to filter disponible only disponible hours
function create_time_range_filter($start='9:00:00', $end='18:00:00', $interval = '30 mins',$array) {
    $startTime = strtotime($start); 
    $endTime   = strtotime($end);
    $current   = time(); 
    $addTime   = strtotime('+'.$interval, $current); 
    $diff      = $addTime - $current;
    $res = array();

    $filtered_times = array(); 
    while ($startTime < $endTime) {
        if(!in_array(date('H:i:s', $startTime),$array)) {
            // you had a problem with your own time formatting
            array_push($filtered_times,date('H:i:s', $startTime)); 
        }
        $startTime += $diff;
    }
    return $filtered_times; 
}
function display_time($filtered_times) {
    // filtered times = times + date
    $times = $filtered_times ;
    echo "<option value=''>choisir une heure</option>";
    foreach($times as $time) {
    echo "<option value=$time>$time</option>";
    }

}
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["date_rdv"])) {
    $date_rdv = $_GET["date_rdv"];
    $_SESSION['date_rdv'] = $date_rdv;
    $current_date = date("Y-m-d");
    if($date_rdv < $current_date) {
        header("location:rdv_mem.php?error=invalid_date");
        exit();
    }
    try {
    $hours = array();
    $conn = mysqli_connect("localhost:3308","root","","adoption_db");
    $sql_heure = "SELECT * FROM rendez_vous WHERE date_rdv = '{$date_rdv}'";
    $query_heure = mysqli_query($conn,$sql_heure);
    while($row = mysqli_fetch_assoc($query_heure)) {
        array_push($hours,$row["heure_rdv"]);
    }
    $filtered_times = create_time_range_filter($start='9:00:00', $end='18:00:00', $interval = '30 mins',$hours,$date_rdv);
    } catch (Exception $e) {
        // If an exception is caught, handle it
        header("location:rdv_mem.php");
        exit();
    }
}
?>


<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Helpa Membre</title>
        <link rel="icon" type="image/x-icon" href="images/fav.png">

        <!-- CSS FILES -->        
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/templatemo-kind-heart-charity.css" rel="stylesheet">
        <style>
            .container1 {
               display: flex;
               justify-content: space-between;
               align-items: center;
               max-width: 1000px; /* Adjust as needed */
               margin: 0 auto;
            }

            .container0 {
                flex: 0 0 50%; /* Take up 50% of the available space */
                background-color: #f0f8ff;
                border-radius: 8px;
                padding: 20px;
                text-align: left;
            }

            .image-container {
                flex: 0 0 50%; /* Take up 40% of the available space */
                margin-left: 60px; /* Add space between the appointment form and the image */
            }

            .image-container img {
                max-width: 100%;
                height: auto;
                display: block;
            }
            .form-group0 {
                margin-bottom: 20px;
            }
            label {
                display: block;
                font-weight: bold;
                margin-bottom: 5px;
                }
            input[type="date"],
            select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }

            input[type="submit"] {
                    display: block;
                    width: 100%;
                    padding: 10px;
                    background-color: #5bc1ac; /* Couleur de fond du bouton */
                    color: #ffffff; /* Couleur du texte du bouton */
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
            }

            input[type="submit"]:hover {
                  background-color: #4ca89d; /* Couleur de fond du bouton au survol */
            }
            .custom-alert{
                position: fixed;
                top: 25%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 500px; /* Adjust the width as needed */
                z-index: 1; /* Ensure it appears on top */
            }
        </style>
         
    </head>
    
<body id="section_1">

<header class="site-header">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-8 col-12 d-flex flex-wrap">
                        <p class="d-flex me-4 mb-0">
                            <i class="bi-geo-alt me-2"></i>
                            Route Sidi Bouzid BP 63 Rue Sidi M'Barek, Safi 46000
                        </p>

                        <p class="d-flex mb-0">
                            <i class="bi-envelope me-2"></i>

                            <a href="mailto:helpaassociation@gmail.com">
                                helpaassociation@gmail.com
                            </a>
                        </p>
                    </div>

                    <div class="col-lg-3 col-12 ms-auto d-lg-block d-none">
                        <ul class="social-icon">
                            <li class="social-icon-item">
                                <a href="https://www.facebook.com/profile.php?id=61558565200373" class="social-icon-link bi-facebook"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://www.instagram.com/helpaassociation/" class="social-icon-link bi-instagram"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://www.youtube.com/channel/UCv9zhnnTI0wNZgYWvgpbFmA" class="social-icon-link bi-youtube"></a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </header>

        <nav class="navbar navbar-expand-lg bg-light shadow-lg">
            <div class="container">
                <a class="navbar-brand" href="Home.html">
                    <img src="mini_projet/images/logo1.png" class="logo img-fluid" alt="Kind Heart Charity">
                    <span>
                        Helpa
                        <small>Association d'adoption d'animaux</small>
                    </span>
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="Home.html">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="adopt.php">Adopter un animal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="member_form.php">Devenir bénévole</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<br>
<br>

    <div id = "message_s" class="alert alert-success custom-alert" role="alert" style="display:none;"></div>
    <div id = "message_e" class="alert alert-danger custom-alert" role="alert" style="display:none;"></div>

<!-- the code of appointement-->
<div class="container1">
    <div class="container0">
        <h2>Prendre un rendez-vous</h2>
        <!-- first form-->
        <form action="rdv_mem.php" method="get">
            <div class="form-group0">
                <label for="date_rdv">Date :</label>
                <input type="date" id="date" name="date_rdv" required value = <?php if(!empty($_SESSION['date_rdv'])) { echo $_SESSION['date_rdv'];}?>>
                <input type="submit" value="Choisir une date">
            </div>
        </form>

        <!-- second form-->
        <form action="member_form_conn.php" method="post">
           <div class="form-group0">
                <input type="hidden" name = "date_rdv" value = <?php if(!empty($_SESSION['date_rdv'])) { echo $_SESSION['date_rdv'];} ?>>
                <label for="heure_rdv">Heure :</label>
                <select id="heure" name="heure_rdv" required>
                    <?php display_time($filtered_times);?>
                </select>
           </div>
  
      <input type="submit" value="Prendre un rendez-vous">
    </form>
    </div>
    
    <div class="image-container">
         <img src="mini_projet/images/once.gif" alt="Appointment Image">
    </div>
</div>

  <!--the end of the code-->
  <br/>
  <br/>

  <footer class="site-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-12 mb-4">
                            <img src="mini_projet/images/logo1.png" class="logo img-fluid" alt="">
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 mb-4">
                            <h5 class="site-footer-title mb-3">Liens Rapides</h5>
                            <ul class="footer-menu d-flex flex-column">
                                <li class="footer-menu-item"><a href="Home.html" class="footer-menu-link">Accueil</a></li>

                                <li class="footer-menu-item"><a href="donate.html" class="footer-menu-link">Faire un don</a></li>

                                <li class="footer-menu-item"><a href="member_form.php" class="footer-menu-link">Devenir bénévole</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 mx-auto">
                            <h5 class="site-footer-title mb-3">Coordonnées</h5>

                            <p class="text-white d-flex mb-2">
                                <i class="bi-telephone me-2"></i>
                                <a href="tel:0688062914" class="site-footer-link">0688062914</a>
                            </p>

                            <p class="text-white d-flex">
                                <i class="bi-envelope me-2"></i>
                                <a href="mailto:helpaassociation@gmail.com" class="site-footer-link">helpaassociation@gmail.com</a>
                            </p>

                            <p class="text-white d-flex mt-3">
                                <i class="bi-geo-alt me-2"></i>
                                Route Sidi Bouzid BP 63 Rue Sidi M'Barek, Safi 46000
                            </p>

                            <a href="https://www.google.com/maps/place/ENSA+:+%C3%89cole+Nationale+des+Sciences+Appliqu%C3%A9es_Safi/@32.3268093,-9.2661967,17.02z/data=!4m6!3m5!1s0xdac2176b55d2d85:0x8f039c8e14c1a1af!8m2!3d32.326826!4d-9.2636605!16s%2Fm%2F0m0krrm?entry=ttu" class="custom-btn btn mt-3">Obtenir l'itinéraire</a>
                        </div>
                    </div>
                </div>
                <div class="site-footer-bottom">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-7 col-12">
                                <p class="copyright-text mb-0">Droits d'auteur © 2024 <a href="Home.html">Helpa</a></p>
                            </div>
                            <div class="col-lg-6 col-md-5 col-12 d-flex justify-content-center align-items-center mx-auto">
                                <ul class="social-icon">
                                    <li class="social-icon-item">
                                        <a href="https://www.facebook.com/profile.php?id=61558565200373" class="social-icon-link bi-facebook"></a>
                                    </li>
                                    <li class="social-icon-item">
                                        <a href="https://www.instagram.com/helpaassociation/" class="social-icon-link bi-instagram"></a>
                                    </li>
                                    <li class="social-icon-item">
                                        <a href="https://www.youtube.com/channel/UCv9zhnnTI0wNZgYWvgpbFmA" class="social-icon-link bi-youtube"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
        </footer>
</body>


<script>
        var urlParams = new URLSearchParams(window.location.search);
            var error = urlParams.get('error');
            var success = urlParams.get('success');
            
            if (error) {
                switch(error) {
                case "unexpected_error":
                // Display error message based on error type
                    errorMessage = "Erreur inattendue. Veuillez réessayer plus tard.";
                    document.getElementById('message_e').innerHTML = errorMessage;
                    document.getElementById('message_e').style.display = 'block';
                    break;
                case "invalid_date":
                    // Display error message based on error type
                    errorMessage = "La date que vous avez choisie est invalide. Veuillez en choisir une autre.";
                    document.getElementById('message_e').innerHTML = errorMessage;
                    document.getElementById('message_e').style.display = 'block';
                    break;
            } 
        }
        else if (success){
            switch(success) {
                case "booked":
            // Display  success message based on success type
                    errorMessage = "Réservé. Vous avez terminé votre demande avec succès. Veuillez vérifier son état en vous connectant à l'aide de votre e-mail et du mot de passe fournis.";
                    document.getElementById('message_s').innerHTML = errorMessage;
                    document.getElementById('message_s').style.display = 'block';
                    break;
            // Display success message
            } 
        }
        function removeQueryParams() {
            window.history.replaceState({}, document.title, window.location.pathname);
        }
        setTimeout(function() {
            document.getElementById('message_e').style.display = 'none';}, 3000); // 3000 milliseconds = 3 seconds
        setTimeout(function() {
            document.getElementById('message_s').style.display = 'none';}, 4000); // 3000 milliseconds = 3 seconds
            

        // Call the function to remove query parameters when the page loads
        window.onload = removeQueryParams;
        setTimeout()
    </script>
</html>

