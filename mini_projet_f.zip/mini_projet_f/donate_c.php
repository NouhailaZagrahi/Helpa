<?php
session_start();
/*try{*/
    $conn = mysqli_connect("localhost:3308","root","","adoption_db");
    if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["donation-fname"])) {
        $nom_don= $_POST["donation-fname"];
        $prenom_don= $_POST["donation-lname"];
        $email_don= $_POST["donation-email"];
        $devise= $_POST["devise"];
        $freq= $_POST["DonationFrequency"];
        $montant= $_POST["flexRadioDefault"];
        $_SESSION["nom_don"] = $nom_don;
        $_SESSION["prenom_don"] = $prenom_don;
        $_SESSION["donation-email"] = $email_don;
        $_SESSION["devise"] = $devise;
        $_SESSION["DonationFrequency"] = $freq;
        $_SESSION["flexRadioDefault"] = $montant ;
    }
/*}

catch (Exception $e) {
    // Si une exception est attrapée, gérez-la
    header("location:donate.html?error=unexpected_error");
    exit();
}*/
?>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Helpa Donation</title>
    <link rel="icon" type="image/x-icon" href="images/fav.png">

    <!-- FICHIERS CSS -->        
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons.css" rel="stylesheet">
    <link href="css/templatemo-kind-heart-charity.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        #currency-select {
            font-size: 18px; /* Ajuster la taille de la police si nécessaire */
        }
        .custom-alert {
            position: fixed;
            top: 25%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px; /* Ajuster la largeur si nécessaire */
            z-index: 1; /* Assurer qu'elle apparaît en haut */
        }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12 d-flex flex-wrap">
                    <p class="d-flex me-4 mb-0">
                        <i class="bi-geo-alt me-2"></i>
                        Route Sidi Bouzid BP 63 Rue Sidi M'Barek, Safi 46000
                    </p>
                    <p class="d-flex mb-0">
                        <i class="bi-envelope me-2"></i>
                        <a href="mailto:helpaassociation@gmail.com">
                           helpaassociation@gmail.com
                        </a>
                    </p>
                </div>
                <div class="col-lg-3 col-12 ms-auto d-lg-block d-none">
                        <ul class="social-icon">
                            <li class="social-icon-item">
                                <a href="https://www.facebook.com/profile.php?id=61558565200373" class="social-icon-link bi-facebook"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://www.instagram.com/helpaassociation/" class="social-icon-link bi-instagram"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://www.youtube.com/channel/UCv9zhnnTI0wNZgYWvgpbFmA" class="social-icon-link bi-youtube"></a>
                            </li>
                        </ul>
                    </div>
            </div>
        </div>
    </header>
    <nav class="navbar navbar-expand-lg bg-light shadow-lg">
        <div class="container">
            <a class="navbar-brand" href="Home.html">
                <img src="mini_projet/images/logo1.png" class="logo img-fluid" alt="Kind Heart Charity">
                <span>
                    Helpa
                    <small>Association d'adoption d'animaux</small>
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="Home.html">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="adopt.html">Adopter un animal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="member_form.php">Devenir bénévole</a>
                    </li>
                    <li class="nav-item ms-3">
                        <a class="nav-link" href="login.html">Connexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div id = "message_s" class="alert alert-success custom-alert" role="alert" style="display:none;"></div>
    <div id = "message_e" class="alert alert-danger custom-alert" role="alert" style="display:none;"></div>
    <main>
        <section class="donate-section">
            <div class="section-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12 mx-auto">
                        <form class="custom-form donate-form" action="donate_conn.php" method="POST" role="form">
                            <h3 class="mb-4">Informations de facturation</h3>
                            <div class="row">
                                <div class="col-lg-12 col-12 mt-2">
                                    <h5 class="mt-1">Nom sur la carte</h5>
                                    <div class="col-lg-12 col-12">
                                        <input type="text" name="nom_don_c" class="form-control" placeholder="Nom sur la carte" aria-label="Nom d'utilisateur" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-12 mt-2">
                                    <h5 class="mt-1">Numéro de carte</h5>
                                    <div class="col-lg-12 col-12">
                                        <input type="text" name="credit_c_num" class="form-control" placeholder="Numéro de carte" aria-label="Nom d'utilisateur" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-12">
                                </div>
                                <br>
                                <br>
                                <div class="col-lg-6 col-12 mt-2">
                                    <h5 class="mt-1">Mois d'expiration</h5>
                                    <input type="text" name="exp_m" id="donation-name" class="form-control" placeholder="Mois d'expiration" required>
                                </div>
                                <div class="col-lg-6 col-12 mt-2">
                                    <h5 class="mt-1">Année d'expiration</h5>
                                    <input type="text" name="exp_y" id="donation-name" class="form-control" placeholder="Année d'expiration" required>
                                </div>
                                <div class="col-lg-6 col-12 mt-2">
                                    <h5 class="mt-1">CVV</h5>
                                    <input type="text" name="code_v_c" id="donation-email" class="form-control" placeholder="Code de vérification" required>
                                </div>
                                <div class="col-lg-12 col-12 mt-2">
                                    <a href="Thanks.html">
                                        <button type="submit" class="form-control mt-4">Soumettre le don</button>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- FICHIERS JAVASCRIPT -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
    <script>
        function changeCurrencySymbol() {
            var currencySelect = document.getElementById("currency-select");
            var currencyIcon = document.getElementById("currency-icon");
            var customAmountSymbol = document.getElementById("custom-amount-symbol");
            var selectedCurrency = currencySelect.value;
    
            switch (selectedCurrency) {
                case "USD":
                    currencyIcon.innerHTML = '<i class="bi-currency-dollar"></i>';
                    customAmountSymbol.innerText = "$";
                    break;
                case "EUR":
                    currencyIcon.innerHTML = '<i class="bi-currency-euro"></i>';
                    customAmountSymbol.innerText = "€";
                    break;
                case "GBP":
                    currencyIcon.innerHTML = '<i class="bi-currency-pound"></i>';
                    customAmountSymbol.innerText = "£";
                    break;
                case "MAD":
                    currencyIcon.innerHTML = '<i class="fa-solid fa-coins"></i>'; 
                    customAmountSymbol.innerText = "MAD"; 
                    break;
                default:
                    currencyIcon.innerHTML = '<i class="bi-currency-dollar"></i>';
                    customAmountSymbol.innerText = "$";
            }
        }
    </script>
    <script>
        var urlParams = new URLSearchParams(window.location.search);
        var error = urlParams.get('error');
        var success = urlParams.get('success');
        
        if (error) {
            switch(error) {
                case "unexpected_error":
                    // Afficher le message d'erreur en fonction du type d'erreur
                    errorMessage = "Erreur inattendue, veuillez réessayer plus tard";
                    document.getElementById('message_e').innerHTML = errorMessage;
                    document.getElementById('message_e').style.display = 'block';
                    break;
                case "donate":
                    // Afficher le message d'erreur en fonction du type d'erreur
                    errorMessage = "Erreur, veuillez réessayer";
                    document.getElementById('message_e').innerHTML = errorMessage;
                    document.getElementById('message_e').style.display = 'block';
                    break;
            } 
        } else if (success) {
            switch(success) {
                case "inserted":
                    // Afficher le message de succès en fonction du type de succès
                    errorMessage = "Vos données ont été insérées avec succès dans la base de données.";
                    document.getElementById('message_s').innerHTML = errorMessage;
                    document.getElementById('message_s').style.display = 'block';
                    break;
            } 
        }
        function removeQueryParams() {
            window.history.replaceState({}, document.title, window.location.pathname);
        }
        setTimeout(function() {
            document.getElementById('message_e').style.display = 'none';
        }, 3000); // 3000 millisecondes = 3 secondes
        setTimeout(function() {
            document.getElementById('message_s').style.display = 'none';
        }, 3000); // 3000 millisecondes = 3 secondes

        // Appeler la fonction pour supprimer les paramètres de requête lorsque la page se charge
        window.onload = removeQueryParams;
    </script>
</body>
</html>