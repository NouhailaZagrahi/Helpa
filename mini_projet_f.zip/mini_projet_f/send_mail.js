function envoyerMessage(type) {
    var emoji = emojione.toShort("🥳🥳"); 
    const email = document.getElementById("email").value;
    const name = document.getElementById("name").value;
    if(type) {
        message =`Cher ${name},

        Nous sommes ravis de vous adresser nos plus chaleureuses félicitations ${emoji}pour votre récente admission en tant que membre de l'Association d'Adoption d'Animaux Helpa. 
        Votre dévouement et votre passion ont certainement porté leurs fruits, et c'est inspirant de vous voir reconnu par une association aussi prestigieuse. 
        C'est non seulement une étape importante dans votre parcours, mais aussi un témoignage de votre travail acharné et de votre engagement envers l'excellence.
        
        Cordialement,
        
        Helpa`
        const corpsMessage = encodeURIComponent(message);
        if(email) {
            window.location.href = `mailto:${email}?subject=Accepted%20As%20a%20Member&body=${corpsMessage}`;
        }
    }
    else {
        message=`Cher ${name},

        Nous espérons que ce message vous trouve en bonne santé. Nous vous écrivons concernant votre récente demande d'adhésion à l'Association d'Adoption d'Animaux Helpa.
        Nous apprécions le temps et les efforts que vous avez investis dans votre demande ainsi que votre intérêt pour rejoindre notre communauté.
        
        Après une délibération attentive et un processus d'examen approfondi, nous regrettons de vous informer que nous ne sommes pas en mesure de vous offrir une adhésion pour le moment. 
        Veuillez considérer cela non pas comme un rejet, mais comme une incitation à présenter une nouvelle demande à l'avenir.
        
        Cordialement,
        
        Helpa`
        const corpsMessage = encodeURIComponent(message);
        if(email) {
            window.location.href = `mailto:${email}?subject=Membership%20Application%20Update&body=${corpsMessage}`;
    }
}
    }
    /*// Votre code JavaScript pour envoyer le message
    // Exemple : récupérer les valeurs des champs de saisie
    const email = document.getElementById("email").value;

    // Vérifier la validité de l'adresse email
    if (!validateEmail(email)) {
        alert("Adresse email invalide");
        return; 
    }

    // Pré-remplir le corps du message avec "Vous êtes accepté"
    const corpsMessage = encodeURIComponent("Vous êtes accepté");

    // Ouvrir une fenêtre de messagerie avec le client de messagerie par défaut
    window.location.href = `mailto:${email}?subject=Acceptation%20de%20votre%20candidature&body=${corpsMessage}`;
}

// Fonction pour valider l'adresse email
function validateEmail(email) {
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regex.test(email);*/