<?php
define('MAILHOST',"smtp.gmail.com");
define('USERNAME',"ihssanenedjaoui5@gmail.com");
define('PASSWORD','dlxe bysi zmjh htwq');
define('SEND_FROM','ihssanenedjaoui5@gmail.com');
define('SEND_FROM_Name','ihssanenedjaoui');
/*define('REPLY_TO','helpaassociation@gmail.com');
define('REPLY_TO_NAME','Helpa');*/






?>